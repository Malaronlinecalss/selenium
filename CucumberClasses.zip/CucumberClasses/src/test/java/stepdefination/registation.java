package stepdefination;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class registation {
	@Given("launching the url using user defined")
	public void launching_the_url_using_user_defined() {
		WebDriver driver=new ChromeDriver();
		driver.get("https://mvnrepository.com/search?q=selenium");
	}
	@Given("launching the url")
	public void launching_the_url() {
		
	}
	@Given("launching the url {string}")
	public void launching_the_url(String url) {
		System.out.println("the url :"+url);
	}
	@Given("generate the token")
	public void generate_the_token() {
	}
	@When("after opening the url user need to ener all the required info into registation form")
	public void after_opening_the_url_user_need_to_ener_all_the_required_info_into_registation_form() {
	}
	@When("enter the capth")
	public void enter_the_capth() {
	}
	@When("select the confirmation you are not a robot")
	public void select_the_confirmation_you_are_not_a_robot() {
	}
	@Then("validate the account is created or not")
	public void validate_the_account_is_created_or_not() {
	}
	@Then("verify the email is sent to the secondary email or not")
	public void verify_the_email_is_sent_to_the_secondary_email_or_not() {
	}
	@Then("verify the message is sent to the primay mobile number or not")
	public void verify_the_message_is_sent_to_the_primay_mobile_number_or_not() {
	}	
}
