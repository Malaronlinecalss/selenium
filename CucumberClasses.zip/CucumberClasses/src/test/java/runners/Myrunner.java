package runners;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features ="C:\\Users\\Rakhesh reddy gowrav\\Malar\\CucumberClasses\\src\\test\\resources\\FeatureFiles",tags="@Reg",glue="stepdefination",plugin={"json:CucumberClasses\\Reports\\cucumber.json","html:CucumberClasses\\Reports\\cucumber.html"})
public class Myrunner {

}
